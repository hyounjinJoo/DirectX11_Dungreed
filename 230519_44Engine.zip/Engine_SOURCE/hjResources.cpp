#include "hjResources.h"

namespace hj
{
	std::map<std::wstring, std::shared_ptr<Resource>> Resources::mResources;
}
