#include "hjResource.h"

namespace hj
{
	Resource::Resource(eResourceType type)
		: mType(type)
	{
	}
	Resource::~Resource()
	{
		int a = 0;
	}
}