#include "hjStage1BossHand.h"
#include "hjStage1Boss.h"
#include "hjSpriteRenderer.h"
#include "hjAnimation.h"
#include "hjAnimator.h"
#include "hjResources.h"

namespace hj
{
	Stage1BossHand::Stage1BossHand()
		: mOwner(nullptr)
		, mHandType(Boss1HandType::End)
		, mHandState(Boss1HandState::End)
	{
		SetName(WIDE("Boss_Bellial_Hand"));

		// 1. Sprite Renderer ����
		SpriteRenderer* sr = AddComponent<SpriteRenderer>();
		std::shared_ptr<Material> material = MTRL_FIND("MTRL_Monster_Boss_Bellial");
		std::shared_ptr<Mesh> mesh = MESH_FIND("Mesh_Rect");
		sr->SetMaterial(material);
		sr->SetMesh(mesh);

		// 2. Body Animator ���� �� Animation �߰�
		Animator* animator = AddComponent<Animator>();
		if (material && animator)
		{
			std::shared_ptr<Texture> texture = material->GetTexture(eTextureSlot::T0);
			if (texture)
			{
				CreateAnimation();
			}
		}
	}

	Stage1BossHand::~Stage1BossHand()
	{
		if (mOwner)
			mOwner = nullptr;
	}
	
	void Stage1BossHand::Initialize()
	{
		GameObject::Initialize();
	}
	
	void Stage1BossHand::Update()
	{
		GameObject::Update();
	}
	
	void Stage1BossHand::FixedUpdate()
	{
		GameObject::FixedUpdate();
	}
	
	void Stage1BossHand::Render()
	{
		GameObject::Render();
	}
	
	void Stage1BossHand::SetOwner(Stage1Boss* owner)
	{
		if (!owner)
		{
			return;
		}

		if (!dynamic_cast<Stage1Boss*>(owner))
		{
			return;
		}

		mOwner = owner;
	}

	void Stage1BossHand::ChangeHandState(Boss1HandState nextState)
	{
		if (mHandState == nextState)
			return;

		Animator* animator = GetComponent<Animator>();
		if (!animator)
			return;

		switch (nextState)
		{
		case hj::Boss1HandState::Idle:
			animator->Play(WIDE("Bellial_HandIdle"));
			break;
		case hj::Boss1HandState::Attack:
			animator->Play(WIDE("Bellial_HandAttack"), false);
			break;
		case hj::Boss1HandState::End:
		default:
			break;
		}
	}

	void Stage1BossHand::ChangeHandType(Boss1HandType handType)
	{
		if (Boss1HandType::End == handType)
			return;

		mHandType = handType;
		switch (handType)
		{
		case hj::Boss1HandType::Left:
			SetName(WIDE("Boss_Bellial_Hand_L"));
			SetRotationY(DegreeToRadian(0.f));
			break;
		case hj::Boss1HandType::Right:
			SetName(WIDE("Boss_Bellial_Hand_R"));
			SetRotationY(XM_PI);
			break;
		case hj::Boss1HandType::End:
		default:
			break;
		}
	}

	void Stage1BossHand::CreateAnimation()
	{

		SpriteRenderer* sr = GetComponent<SpriteRenderer>();
		std::shared_ptr<Material> material = sr->GetMaterial();
		std::shared_ptr<Texture> texture = material->GetTexture(eTextureSlot::T0);
		Vector2 atlasTexSize = texture->GetTexSize();

		float duration = 0.f;
		duration = 1.f / 15.f;
		CREATE_ANIM(animBellialHandIdle, frame, atlasTexSize, duration);
		FRAME_ADD_OFFSETX(frame, 1585.f, 555.f, 275.f, 295.f, 0.5, animBellialHandIdle);
		FRAME_ADD_OFFSETX(frame, 0.f, 860.f, 280.f, 310.f, 0.5, animBellialHandIdle);
		FRAME_ADD_OFFSETX(frame, 875.f, 860.f, 280.f, 315.f, 0.5, animBellialHandIdle);
		FRAME_ADD_OFFSETX(frame, 280.f, 860.f, 285.f, 315.f, 0.5, animBellialHandIdle);
		FRAME_ADD_OFFSETX(frame, 2135.f, 555.f, 285.f, 305.f, 0.5, animBellialHandIdle);
		FRAME_ADD_OFFSETX(frame, 1860.f, 555.f, 275.f, 300.f, 0.5, animBellialHandIdle);
		FRAME_ADD_OFFSETX(frame, 1320.f, 555.f, 265.f, 290.f, 0.5, animBellialHandIdle);
		FRAME_ADD_OFFSETX(frame, 785.f, 555.f, 265.f, 275.f, 0.5, animBellialHandIdle);
		FRAME_ADD_OFFSETX(frame, 520.f, 555.f, 265.f, 275.f, 0.5, animBellialHandIdle);
		FRAME_ADD_OFFSETX(frame, 1050.f, 555.f, 270.f, 285.f, 0.5, animBellialHandIdle);
		

		CREATE_SHEET(animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 280.f, 860.f, 285.f, 315.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 1260.f, 860.f, 295.f, 330.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 1445.f, 285.f, 260.f, 260.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 1175.f, 285.f, 270.f, 250.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 1705.f, 285.f, 260.f, 260.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 1965.f, 285.f, 260.f, 265.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 2225.f, 285.f, 260.f, 270.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 0.f, 555.f, 260.f, 270.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 260.f, 555.f, 260.f, 270.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 565.f, 860.f, 310.f, 315.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 1555.f, 860.f, 295.f, 335.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 1555.f, 860.f, 295.f, 335.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 1555.f, 860.f, 295.f, 335.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 1555.f, 860.f, 295.f, 335.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 2135.f, 555.f, 285.f, 305.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 1050.f, 555.f, 270.f, 285.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 520.f, 555.f, 265.f, 275.f, 0.5f, animBellialHandAttack);
		FRAME_ADD_OFFSETX(frame, 1050.f, 555.f, 270.f, 285.f, 0.5f, animBellialHandAttack);

		AUTO_OFFSET_CALC_Y(animBellialHandIdle);
		AUTO_OFFSET_CALC_Y(animBellialHandAttack);

		Animator* animator = GetComponent<Animator>();

		std::wstring idleAnimWstr = WIDE("Bellial_HandIdle");
		std::wstring attackAnimWstr = WIDE("Bellial_HandAttack");

		animator->Create(idleAnimWstr, texture, animBellialHandIdle, canvasSize, false);
		animator->Create(attackAnimWstr, texture, animBellialHandAttack, canvasSize, false);

		animator->Play(idleAnimWstr, true);

		SetScaleXY(canvasSize);
		GetTransform()->FixedUpdate();
	}
}