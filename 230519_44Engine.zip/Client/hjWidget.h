#pragma once

namespace hj::gui
{
	class Widget
	{
	};
}
