#include "hjMonster.h"

namespace hj
{
	Monster::Monster()
	{
	}

	Monster::~Monster()
	{
	}

	void Monster::Initialize()
	{
	}

	void Monster::Update()
	{
	}

	void Monster::FixedUpdate()
	{
	}

	void Monster::Render()
	{
	}
}