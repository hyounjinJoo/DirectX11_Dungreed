#include "hjStage1Boss.h"
#include "hjSpriteRenderer.h"
#include "hjResources.h"
#include "hjAnimator.h"
#include "hjCollider2D.h"
#include "hjObject.h"
#include "hjTime.h"
#include "hjStage1BossHand.h"

namespace hj
{
#define Bellial_Horn_X_Size_Ratio 0.10714f

	Stage1Boss::Stage1Boss()
	{
		SetName(WIDE("Boss_Bellial"));

		// 1. Sprite Renderer ����
		SpriteRenderer* sr = AddComponent<SpriteRenderer>();
		std::shared_ptr<Material> material = MTRL_FIND("MTRL_Monster_Boss_Bellial");
		std::shared_ptr<Mesh> mesh = MESH_FIND("Mesh_Rect");
		sr->SetMaterial(material);
		sr->SetMesh(mesh);

		// 2. Body Animator ���� �� Animation �߰�
		Animator* animator = AddComponent<Animator>();
		if (material && animator)
		{
			std::shared_ptr<Texture> texture = material->GetTexture(eTextureSlot::T0);
			if (texture)
			{
				CreateBodyAnimation();
			}
		}

		// 3. Damage ������ ��ü�� �浹ü ����
		mDamageBody = object::Instantiate<GameObject>(eLayerType::Monster);

		Vector2 bodySize = GetComponent<Animator>()->GetCurrentAnimation()->GetCurrentSpriteSize();
		bodySize.x *= 0.785f;
		mDamageBody->SetScaleXY(bodySize);
		float movedPos = GetScaleX() * Bellial_Horn_X_Size_Ratio;
		mDamageBody->AddPositionX(movedPos);
		mDamageBody->GetTransform()->SetParent(this->GetTransform());

		mDamageBody->GetTransform()->FixedUpdate();

		mDamageCollider = mDamageBody->AddComponent<Collider2D>();

		// 4. Left Hand, Right Hand ����
		mLeftHand = object::Instantiate<Stage1BossHand>(eLayerType::MonsterHas, Vector3(80.f * -7.f, 80.f * -3.f, 1.f));
		mRightHand = object::Instantiate<Stage1BossHand>(eLayerType::MonsterHas, Vector3(80.f * 7.f, 0.f, 1.f));

		mLeftHand->ChangeHandType(Boss1HandType::Left);
		mRightHand->ChangeHandType(Boss1HandType::Right);

		mLeftHand->ChangeHandState(Boss1HandState::Idle);
		mRightHand->ChangeHandState(Boss1HandState::Idle);


		// 5. SkellBossBack �̹��� ��ü ���� 
		mBackground = object::Instantiate<GameObject>(eLayerType::MonsterHas, Vector3(GetScaleX() * 0.5f, 0.f, 1.f));
		// 6. Effect ��ü ����
		{
		//		(1) DieFX ���� ��ü ����
			mBackground = object::Instantiate<GameObject>(eLayerType::MonsterHas, Vector3(GetScaleX() * 0.5f, 0.f, 1.f));
		//		(2) BackgroundParticle �̹��� ��ü ���� Ȥ�� ��ƼŬ ����
			mBackground = object::Instantiate<GameObject>(eLayerType::MonsterHas, Vector3(GetScaleX() * 0.5f, 0.f, 1.f));
		}
		// 7. Pattern 1(Summon Sword)�� �ʿ��� �͵� ����
		
		// 8. Pattern 2(Fire Bullets)�� �ʿ��� �͵� ����
		// 9. Pattern 3(Shot Laser)�� �ʿ��� �͵� ����
		
	}
	Stage1Boss::~Stage1Boss()
	{
	}
	void Stage1Boss::Initialize()
	{
		GameObject::Initialize();
	}

	void Stage1Boss::Update()
	{
		GameObject::Update();
	}

	void Stage1Boss::FixedUpdate()
	{
		static float testTime = 0.f;
		static float testMaxTime = 5.f;

		Vector2 bodySize = GetComponent<Animator>()->GetCurrentAnimation()->GetCurrentSpriteSize();
		bodySize.x *= 0.785f;
		bodySize.y -= 77.5f;
		float moveY = GetScaleY() * 0.5f - bodySize.y * 0.5f;
		mDamageBody->SetScaleXY(bodySize);
		mDamageBody->SetPositionY(-moveY);

		if (testTime < testMaxTime)
		{
			testTime += Time::ActualDeltaTime();
			Animator* animator = GetComponent<Animator>();
			
			if (testTime > testMaxTime)
			{
				testTime = 0.f;
				
				if (animator->GetCurrentAnimation()->AnimationName()._Equal(WIDE("Bellial_Idle")))
				{
					animator->Play(WIDE("Bellial_AttackStart"), false);
				}
				else if (animator->GetCurrentAnimation()->AnimationName()._Equal(WIDE("Bellial_Attack")))
				{
					animator->Play(WIDE("Bellial_AttackEnd"), true);
				}
			}
			else
			{
				Animation* anim = animator->GetCurrentAnimation();
				std::wstring curAnimName = anim->AnimationName();
				if (curAnimName._Equal(WIDE("Bellial_AttackStart")))
				{
					if (anim->IsComplete())
					{
						testTime = 0.f;
						animator->Play(WIDE("Bellial_Attack"));
					}
				}
				else if (curAnimName._Equal(WIDE("Bellial_AttackEnd")))
				{
					if (anim->IsComplete())
					{
						testTime = 0.f;
						animator->Play(WIDE("Bellial_Idle"));
					}
				}
			}
		}

		GameObject::FixedUpdate();
	}

	void Stage1Boss::Render()
	{
		GameObject::Render();
	}

	void Stage1Boss::Damaged(float damage)
	{

	}

	void Stage1Boss::CreateBodyAnimation()
	{
		SpriteRenderer* sr = GetComponent<SpriteRenderer>();
		std::shared_ptr<Material> material = sr->GetMaterial();
		std::shared_ptr<Texture> texture = material->GetTexture(eTextureSlot::T0);
		Vector2 atlasTexSize = texture->GetTexSize();


		float duration = 0.f;
		duration = 1.f / 10.f;
		CREATE_ANIM(animBellialIdle, frame, atlasTexSize, duration);
		FRAME_ADD_OFFSETX(frame, 1050.f, 1245.f, 350.f, 455.f, 0.5f,animBellialIdle);
		FRAME_ADD_OFFSETX(frame, 1400.f, 1245.f, 350.f, 460.f, 0.5f,animBellialIdle);
		FRAME_ADD_OFFSETX(frame, 1750.f, 1245.f, 350.f, 465.f, 0.5f,animBellialIdle);
		FRAME_ADD_OFFSETX(frame, 1750.f, 1245.f, 350.f, 465.f, 0.5f,animBellialIdle);
		FRAME_ADD_OFFSETX(frame, 1050.f, 1245.f, 350.f, 455.f, 0.5f,animBellialIdle);
		FRAME_ADD_OFFSETX(frame, 700.f, 1245.f, 350.f, 450.f, 0.5f, animBellialIdle);
		FRAME_ADD_OFFSETX(frame, 350.f, 1245.f, 350.f, 440.f, 0.5f, animBellialIdle);
		FRAME_ADD_OFFSETX(frame, 0.f, 1245.f, 350.f, 435.f, 0.5f, animBellialIdle);
		FRAME_ADD_OFFSETX(frame, 350.f, 1245.f, 350.f, 440.f, 0.5f, animBellialIdle);
		FRAME_ADD_OFFSETX(frame, 700.f, 1245.f, 350.f, 450.f, 0.5f, animBellialIdle);

		CREATE_SHEET(animBellialAttack);		
		FRAME_ADD_OFFSETX(frame, 700.f, 1830.f, 350.f, 630.f, 0.5f, animBellialAttack);
		FRAME_ADD_OFFSETX(frame, 1050.f, 1830.f, 350.f, 630.f, 0.5f, animBellialAttack);
		FRAME_ADD_OFFSETX(frame, 1400.f, 1830.f, 350.f, 630.f, 0.5f, animBellialAttack);
		FRAME_ADD_OFFSETX(frame, 1750.f, 1830.f, 350.f, 630.f, 0.5f, animBellialAttack);

		CREATE_SHEET(animBellialAttackStart);
		FRAME_ADD_OFFSETX(frame, 1050.f, 1245.f, 350.f, 455.f, 0.5f, animBellialAttackStart);
		FRAME_ADD_OFFSETX(frame, 350.f, 1245.f, 350.f, 440.f, 0.5f, animBellialAttackStart);
		FRAME_ADD_OFFSETX(frame, 700.f, 1245.f, 350.f, 450.f, 0.5f, animBellialAttackStart);
		FRAME_ADD_OFFSETX(frame, 2100.f, 1245.f, 350.f, 585.f, 0.5f, animBellialAttackStart);
		FRAME_ADD_OFFSETX(frame, 0.f, 1830.f, 350.f, 610.f, 0.5f, animBellialAttackStart);
		FRAME_ADD_OFFSETX(frame, 350.f, 1830.f, 350.f, 620.f, 0.5f, animBellialAttackStart);

		CREATE_SHEET(animBellialAttackEnd);
		FRAME_ADD_OFFSETX(frame, 350.f, 1830.f, 350.f, 620.f, 0.5f, animBellialAttackEnd);
		FRAME_ADD_OFFSETX(frame, 0.f, 1830.f, 350.f, 610.f, 0.5f, animBellialAttackEnd);
		FRAME_ADD_OFFSETX(frame, 2100.f, 1245.f, 350.f, 585.f, 0.5f, animBellialAttackEnd);
		FRAME_ADD_OFFSETX(frame, 700.f, 1245.f, 350.f, 450.f, 0.5f, animBellialAttackEnd);
		FRAME_ADD_OFFSETX(frame, 350.f, 1245.f, 350.f, 440.f, 0.5f, animBellialAttackEnd);
		FRAME_ADD_OFFSETX(frame, 1050.f, 1245.f, 350.f, 455.f, 0.5f, animBellialAttackEnd);

		AUTO_OFFSET_CALC_Y(animBellialIdle);
		AUTO_OFFSET_CALC_Y(animBellialAttack);
		AUTO_OFFSET_CALC_Y(animBellialAttackStart);
		AUTO_OFFSET_CALC_Y(animBellialAttackEnd);

		Animator* animator = GetComponent<Animator>();

		std::wstring idleAnimWstr = WIDE("Bellial_Idle");
		std::wstring attackAnimWstr = WIDE("Bellial_Attack");
		std::wstring attackStartAnimWstr = WIDE("Bellial_AttackStart");
		std::wstring attackEndAnimWstr = WIDE("Bellial_AttackEnd");

		animator->Create(idleAnimWstr, texture, animBellialIdle, canvasSize, false);
		animator->Create(attackAnimWstr, texture, animBellialAttack, canvasSize, false);
		animator->Create(attackStartAnimWstr, texture, animBellialAttackStart, canvasSize, false);
		animator->Create(attackEndAnimWstr, texture, animBellialAttackEnd, canvasSize, false);

		animator->Play(idleAnimWstr, true);

		AddPositionX(-canvasSize.x * Bellial_Horn_X_Size_Ratio);
		SetScaleXY(canvasSize);
		GetTransform()->FixedUpdate();
	}

	void Stage1Boss::ProcessDamaged(float damage)
	{

	}

	void Stage1Boss::Dead()
	{

	}

	void Stage1Boss::CreateJaws()
	{

	}

}