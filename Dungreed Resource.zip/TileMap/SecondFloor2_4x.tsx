<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="SecondFloor2_4x" tilewidth="64" tileheight="64" tilecount="336" columns="42">
 <image source="SecondFloor2_4x.png" width="2748" height="512"/>
</tileset>
