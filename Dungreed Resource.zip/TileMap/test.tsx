<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="test" tilewidth="32" tileheight="32" tilecount="512" columns="32">
 <image source="Resources/Map.png" width="1024" height="512"/>
</tileset>
