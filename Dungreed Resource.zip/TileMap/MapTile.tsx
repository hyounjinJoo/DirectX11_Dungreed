<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Map4X" tilewidth="64" tileheight="64" tilecount="2048" columns="64">
 <image source="../정리/Map4X.png" width="4096" height="2048"/>
</tileset>
